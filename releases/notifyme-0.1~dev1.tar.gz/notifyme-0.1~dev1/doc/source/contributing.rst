How to contribute
=================

NotifyMe is being developed on github at https://github.com/waaaaargh/notifyme/

Patches, bug reports and feature requests are welcome!
